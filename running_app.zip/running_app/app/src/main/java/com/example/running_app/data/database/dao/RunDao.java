package com.example.running_app.data.database.dao;

public interface RunDao {
}
