package com.example.running_app.ui.viewmodels;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {
}
